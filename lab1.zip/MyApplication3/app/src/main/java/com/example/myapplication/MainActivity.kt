package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numberEditText: EditText = findViewById(R.id.numberEditText)
        val showDivisorsButton: Button = findViewById(R.id.showDivisorsButton)

        showDivisorsButton.setOnClickListener {
            val input = numberEditText.text.toString().toIntOrNull()
            if (input != null && input > 0) {
                val divisors = getDivisors(input)
                val message = if (divisors.isNotEmpty()) {
                    "Дільники для $input: ${divisors.joinToString(", ")}"
                } else {
                    "Нема дільників для $input"
                }
                showToast(message)
            } else {
                showToast("Будь ласка введіть правильне натуральне число")
            }
        }
    }

    private fun getDivisors(number: Int): List<Int> {
        val divisors = mutableListOf<Int>()
        for (i in 1..number) {
            if (number % i == 0) {
                divisors.add(i)
            }
        }
        return divisors
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}